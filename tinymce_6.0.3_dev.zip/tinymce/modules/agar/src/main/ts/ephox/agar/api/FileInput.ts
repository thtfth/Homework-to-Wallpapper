import { cRunOnPatchedFileInput, sRunOnPatchedFileInput, pRunOnPatchedFileInput } from '../file/PatchInputFiles';

export {
  sRunOnPatchedFileInput,
  cRunOnPatchedFileInput,
  pRunOnPatchedFileInput
};
